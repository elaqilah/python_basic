package com.example.perpustakaan;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView isi = findViewById(R.id.dataBuku);
        Button btnTambah = findViewById(R.id.btntambah);
        Button btncek = findViewById(R.id.btncek);
        Button btnhapus = findViewById(R.id.btnhapus);
        DBHelper db = new DBHelper(MainActivity.this);

        btncek.setOnClickListener(view -> {
            ArrayList<Buku> listBuku = db.getBuku();
            if (listBuku.size() > 0){
                for (int i = 0 ; i < listBuku.size() ; i++){
                    isi.setText(isi.getText().toString() + listBuku.get(i).kode+ "-" + listBuku.get(i).judul + listBuku.get(i).pengarang+"\n");
                }
            }else{
                isi.setText("Belum Memasukkan Data");
                isi.setTextSize(18F);
            }
        });
        btnTambah.setOnClickListener(v -> startActivity(new Intent(MainActivity.this,BukuTambah.class)));

        btnhapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                isi.setText("");
            }
        });
    }
}