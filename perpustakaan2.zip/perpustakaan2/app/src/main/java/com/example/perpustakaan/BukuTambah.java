package com.example.perpustakaan;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class BukuTambah extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.tambah_buku);
        EditText kode = findViewById(R.id.edtbuku);
        EditText judul = findViewById(R.id.edtjbuku);
        EditText pengarang = findViewById(R.id.edtpengarang);
        Button btnTambah = findViewById(R.id.btnTambah);
        Button btnCek = findViewById(R.id.btnCekData);

        DBHelper db = new DBHelper(BukuTambah.this);

        btnTambah.setOnClickListener(v -> {
            if (kode.getText().toString().isEmpty() || judul.getText().toString().isEmpty() || pengarang.getText().toString().isEmpty()){
            Toast.makeText(BukuTambah.this, "gagl", Toast.LENGTH_SHORT).show();
            }else{
            db.createData(kode.getText().toString(),judul.getText().toString(),pengarang.getText().toString());
            Toast.makeText(BukuTambah.this,"Sukses",Toast.LENGTH_SHORT).show();
            startActivity(new Intent(BukuTambah.this,MainActivity.class));
            }
        });

        btnCek.setOnClickListener(view -> startActivity(new Intent(BukuTambah.this,MainActivity.class)));
    }
}
