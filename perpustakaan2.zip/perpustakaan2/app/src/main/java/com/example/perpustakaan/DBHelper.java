package com.example.perpustakaan;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.widget.Toast;

import java.util.ArrayList;
public class DBHelper extends SQLiteOpenHelper{
    public SQLiteDatabase db = this.getWritableDatabase();
    public DBHelper(Context context){
        super(context,"PERPUSTAKAAN.db",null,1);
    }

    @Override
    public void onCreate(SQLiteDatabase p0){
        String sql = "CREATE TABLE buku (kode VARCHAR(6), judul VARCHAR(30), PRIMARY KEY (kode));";
        p0.execSQL(sql);
        //
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        //
    }
    public ArrayList<Buku> getBuku(){
        String sql = "SELECT * FROM buku;";
        Cursor cursor = db.rawQuery(sql,null);
        ArrayList<Buku> listBuku = new ArrayList<>();

        if (cursor.moveToFirst()){
            do{
                listBuku.add(new Buku (cursor.getShort(0),
                        cursor.getString(1),
                        cursor.getString(2)));
            }while (cursor.moveToNext());
        }
        cursor.close();
        return listBuku;
    }

    public void createData(String kode, String judul, String pengarang){
        ContentValues cv = new ContentValues();
        cv.put("kode",kode);
        cv.put("judul",judul);
        cv.put("pengarang",pengarang);
        db.insert("buku",null,cv);
//        Toast.makeText(getApplicationContext(),"Sukses",Toast.LENGTH_SHORT);
    }

    public Boolean deletekode (String kode){
        String sql = "DELETE FROM buku WHERE kode = '" + kode + "';";
        Cursor cursor = db.rawQuery(sql,null);
        if (cursor.moveToFirst()){
            return true;
        }
        cursor.close();
        return false;
    }
}
