package com.example.perpustakaan;

public class Buku {
    String kode, judul, pengarang;
    public Buku(short kode, String judul, String pengarang){
        this.kode = String.valueOf(kode);
        this.judul = judul;
        this.pengarang = pengarang;
    }
}
